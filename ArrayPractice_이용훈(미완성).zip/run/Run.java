package com.kh.practice.run;

import java.util.concurrent.ArrayBlockingQueue;

import com.kh.practice.array.ArrayPractice;

public class Run {
	
	public static void main (String[] args) {
		
		ArrayPractice a = new ArrayPractice();
		
		// a.practice1();
		// a.practice2();		//
		// a.practice3();
		// a.practice4();		//
		// a.practice5();		
		// a.practice6();		// 날짜 지정
		// a.practice7();		// 합계쪽	
		// a.practice8();		//
		// a.practice9();		// 숫자를 안 집어넣음.
		
		
		// a.practice10();		// 
		// a.practice11();		// 
		// a.practice12();		// 
		// a.practice13();		// 
		// a.practice14();		// 
		// a.practice15();		// 
		// a.practice16();		// ???
		
		
		
	}
		
	

}

package com.kh.practice.chap01;

import java.util.Scanner;

public class ControlPractice {
	
	/*
	 * 아이디, 비밀번호를 정해두고 로그인 기능을 작성하세요.
		로그인 성공 시 “로그인 성공”,
		아이디가 틀렸을 시 “아이디가 틀렸습니다.“,
		비밀번호가 틀렸을 시 “비밀번호가 틀렸습니다.”를 출력하세요.
	 */
	public void practice5() {
		
		// 스캐너 생성
		Scanner sc = new Scanner(System.in);
		
		// 아이디, 비밀번호 정하기
		String id = "myId";
		String pwd = "myPassword12";
		
		System.out.print("아이디 : ");
		String userId = sc.nextLine();
		
		System.out.print("비밀번호 : ");
		String userPwd = sc.nextLine();
		
		String result = "";
		
		if(id.equals(userId)) { // 아이디가 같을 경우
			
			if(pwd.equals(userPwd)) { // 비밀번호도 같을 경우
				result = "로그인 성공";
			}else { // 아이디는 맞았지만 비번이 틀릴 경우
				result = "비밀번호가 틀렸습니다.";
			}
			
		}else {
			result = "아이디가 틀렸습니다.";
		}
		
		System.out.println(result);
		
		
	}
	/*
	 * 키, 몸무게를 double로 입력 받고 BMI지수를 계산하여 계산 결과에 따라
		저체중/정상체중/과체중/비만을 출력하세요.
		BMI = 몸무게 / (키(m) * 키(m))
		
	 */
	
	public void practice7() {
		// 1. 스캐너 생성
		Scanner sc = new Scanner(System.in);
		
		// 2. 키, 몸무게 입력
		System.out.print("키 : ");
		double height = sc.nextDouble();
		
		System.out.print("몸무게 : ");
		double weight = sc.nextDouble();
		
		// 3. BMI = 몸무게 / (키(m) * 키(m)) 지수 구하기
		double bmi = weight / (height * height);
		
		System.out.println("BMI 지수 : " + bmi);
		
		/*
		 * BMI가 18.5미만일 경우 저체중 / 18.5이상 23미만일 경우 정상체중
			BMI가 23이상 25미만일 경우 과체중 / 25이상 30미만일 경우 비만
			BMI가 30이상일 경우 고도 비만
		 */
		
		String result = "";
		
		if(bmi < 18.5) {
			result = "저체중";
		}else if(bmi < 23) { // 18.5 이상, 근데 23은 안되는 사람
			result = "정상체중";
		}else if(bmi < 25) {
			result = "과체중";
		}else if(bmi < 30) {
			result = "비만";
		}else {
			result = "고도비만";
		}
		
		System.out.println(result);
		
	}
	
	/*
	 * 키보드로 두 개의 정수와 연산 기호를 입력 받아 연산 기호에 맞춰 연산 결과를 출력하세요.
		(단, 두 개의 정수 모두 양수일 때만 작동하며 없는 연산 기호를 입력 했을 시
		“잘못 입력하셨습니다. 프로그램을 종료합니다.” 출력)
	 */
	public void practice8() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("피연산자 1 입력 : ");
		int num1 = sc.nextInt();
		
		System.out.print("피연산자 2 입력 : ");
		int num2 = sc.nextInt();
		
		sc.nextLine(); // 버퍼에 남아있는 엔터 제거 코드 추가
		
		System.out.print("연산자 입력 (+, -, *, /, %) : ");
		char op = sc.nextLine().charAt(0);
		
		int result = 0;
		
		if(num1 > 0 && num2 > 0) { // 둘다 양수
			switch(op) {
			case '+' : result = num1 + num2; break;
			case '-' : result = num1 - num2; break;
			case '*' : result = num1 * num2; break;
			case '/' : result = num1 / num2; break;
			case '%' : result = num1 % num2; break;
			default : System.out.println("잘못 입력했다. 프로그램 종료함."); return; 
			}
		}else { // 양수가 아닌게 있음
			System.out.println("잘못 입력했다. 프로그램 종료함."); return; 
		}
		
		System.out.printf("%d %c %d = %d", num1, op, num2, result);
		
		
	}
	
	// 평가 비율은 중간고사 20%, 기말고사 30%, 과제 30%, 출석 20%로
	public void practice9() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("중간고사 점수 : ");
		double midScore = sc.nextInt();
		
		System.out.print("기말고사 점수 : ");
		double finScore = sc.nextInt();
		
		System.out.print("과제 점수 : ");
		double hwScore = sc.nextInt();
		
		System.out.print("출석 횟수 : ");
		double atScore = sc.nextInt();
		
		System.out.println("================= 결과 =================");
		
		if(atScore < 15) { // 출석에서 탈락
			System.out.println("Fail [출석 회수 부족 (" + (int)atScore + "/20)]");
			return;
		}
		
		/*
		 * 중간고사 점수 (20) : 16.0
		 * 기말고사 점수 (30) : 27.0
		 * 과제제출 점수 (30) : 15.0
		 * 출석횟수 점수 (20) : 15.0
		 * 총점 : 73.0
		 */
		
		// midScore = midScore * 0.2; => 복합대입연산자!!
		midScore *= 0.2;
		finScore *= 0.3;
		hwScore  *= 0.3;
		
		double sumScore = midScore + finScore + hwScore + atScore;
		
		System.out.println("중간 고사 점수(20) : " + midScore);
		System.out.println("기말 고사 점수(30) : " + finScore);
		System.out.println("과제 점수(30) : " + hwScore);
		System.out.println("출석 점수(20) : " + atScore);
		System.out.println("총점 : " + sumScore);
		
		// 70점 이상 : PASS, 70점 미만 : Fail
		if(sumScore >= 70) {
			System.out.println("PASS");
		}else {
			System.out.println("Fail [점수 미달]");
		}
		
	}
	
	public void practice10() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("메뉴 입력  : ");
		int menu = sc.nextInt();
		
		switch(menu) {
		case 1 : practice5(); break;
		case 2 : break;
		default : System.out.println("그런건 없다.");
		}
		
	}
	
	public void test() {
		practice10();
	}
	
	
	

}






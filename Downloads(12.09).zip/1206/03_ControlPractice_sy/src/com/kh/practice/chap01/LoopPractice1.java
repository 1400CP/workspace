package com.kh.practice.chap01;

import java.util.Scanner;

public class LoopPractice1 {

	public void practice11() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("시작 숫자 : ");
		int start = sc.nextInt();
		
		System.out.print("공차 : ");
		int gap = sc.nextInt();
		
		for(int i=1; i<=10; i++) {
			System.out.print(start + " ");
			start += gap;
		}
		
	}
	
	public void practice12() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.print("연산자(+,-,*,/,%) : ");
			String op = sc.nextLine();
			
			if(op.equals("exit")) { // 사용자가 exit를 입력한경우
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			
			System.out.print("정수1 입력 : ");
			int num1 = sc.nextInt();
			
			System.out.print("정수2 입력 : ");
			int num2 = sc.nextInt();
			
			sc.nextLine();
			
			int result = 0;
			
			if(op.equals("/") && num2 == 0) {
				System.out.println("0으로 나눌 수 없습니다. 다시 입력해라.");
			}else {
				switch(op) {
				case "+" : result = num1 + num2; break;
				case "-" : result = num1 - num2; break;
				case "*" : result = num1 * num2; break;
				case "/" : result = num1 / num2; break;
				case "%" : result = num1 % num2; break;
				default :
					System.out.println("없는 연산자 입니다. 다시 입력해주세요");
					continue;
				}
				System.out.printf("%d %s %d = %d\n", num1, op, num2, result);
			}
			
			
		}
	}
	
	public void practice4() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.print("문자열 : ");
			String str = sc.nextLine();
			
			System.out.print("문자 : ");
			char ch = sc.nextLine().charAt(0);
			
			int count = 0;
			for(int i=0; i<str.length(); i++) {
				if(str.charAt(i) == ch) {
					count++;
				}
			}
			
			System.out.println("포함된 개수 : " + count);
			System.out.print("더할래? : ");
			char yn = sc.nextLine().charAt(0);
			
			if(yn == 'n' || yn == 'N') {
				System.out.println("종료한다~");
				break;
			}else if(yn == 'y' || yn == 'Y') {
				
			}else {
				System.out.println("잘못했다. 다시 입력해라");
			}
			
		}
	}
	
	public void upDown() {
		Scanner sc = new Scanner(System.in);
		
		int random = (int)(Math.random() * 100 + 1); // 1~100
		System.out.println(random);
		
		int count = 0;
		while(true) {
			System.out.print("1~100 사이의 임의의 난수를 맞춰보세요 :");
			int num = sc.nextInt();
			
			if(num >0 && num <=100) { // 잘 입력한 경우
				
				count++;
				
				if(num > random) {
					System.out.println("down");
				}else if(num < random) {
					System.out.println("up");
				}else { // 이때 정답 맞춤
					System.out.println("정답입니다~");
					System.out.println(count + "회만에 정답 맞췄다~");
					break;
				}
				
			}else {
				System.out.println("잘못했다~ 다시해라");
			}
		}
		
		
	}
	
	public void rps() {
		Scanner sc = new Scanner(System.in);
		
		int total = 0;		// 전
		int win = 0;		// 승
		int tie = 0;		// 무
		int lose = 0;		// 패
		
		System.out.print("당신의 이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		while(true) {
			int random = (int)(Math.random() * 3 + 1); // 1, 2, 3
			String com = "";
			
			switch(random) {
			case 1 : com = "가위"; break;
			case 2 : com = "바위"; break;
			case 3 : com = "보"; break;
			}
			
			System.out.print("가위바위보 : ");
			String user = sc.nextLine();
			
			if(user.equals("exit")) {
				System.out.printf("%d전 %d승 %d무 %d패", total, win, tie, lose);
				break;
			}else if(user.equals("가위") || user.equals("바위") || user.equals("보")) {
				
				System.out.println("컴퓨터 : " + com);
				System.out.println(name + " : " + user);
				
				String result = "";
				
				if(com.equals(user)) {
					result = "비겼습니다!";
				}
				
				if(com.equals("가위")) { // com이 가위를 낸 경우
					switch(user) {
					case "바위" : result = "이겼습니다."; break;
					case "보" : 	 result = "졌습니다."; break;
					}
				}else if(com.equals("바위")) { // com이 바위를 낸 경우
					switch(user) {
					case "가위" : result = "졌습니다."; break;
					case "보" : result = "이겼습니다."; break;
					}
				}else { // com이 보를 낸 경우
					switch(user) {
					case "가위" : result = "이겼습니다."; break;
					case "바위" : result = "졌습니다."; break;
					}
				}
				System.out.println(result);
				System.out.println();
				
				total++; // 전
				switch(result) {
				case "이겼습니다." : win++; break; // 승++
				case "졌습니다." : lose++; break; // 패++
				default : tie++; break; //무++
				}
				
			}else {
				System.out.println("잘못 입력하셨습니다.");
			}
			
		}
		
	}
	
}









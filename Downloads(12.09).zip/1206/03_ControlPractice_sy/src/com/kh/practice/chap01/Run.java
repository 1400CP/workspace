package com.kh.practice.chap01;

public class Run {
	
	public static void main(String[] args) {
		ControlPractice cp = new ControlPractice();
		//cp.practice10();
		
		LoopPractice lp = new LoopPractice();
		//lp.practice12();
		
		LoopPractice1 lp1 = new LoopPractice1();
		lp1.rps();
	}

}

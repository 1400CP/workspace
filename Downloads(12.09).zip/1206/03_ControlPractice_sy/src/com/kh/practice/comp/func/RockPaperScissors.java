package com.kh.practice.comp.func;

import java.util.Scanner;

public class RockPaperScissors {
	
	public void rps() {
		Scanner sc = new Scanner(System.in);
		
		int total = 0; 	// 전
		int win = 0; 	// 승
		int lose = 0; 	// 무
		int tie = 0; 	// 패
		
		System.out.print("당신의 이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		while(true) {
			int random = (int)(Math.random() * 3 + 1); // 1 2 3
			String com = "";
			
			switch(random) {
			case 1 : com = "가위"; break;
			case 2 : com = "바위"; break;
			case 3 : com = "보"; break;
			}
			
			System.out.print("가위바위보 : ");
			String user = sc.nextLine();
			
			if(user.equals("exit")) {
				
				System.out.printf("%d전 %d승 %d무 %d패", total, win, tie, lose); // 그동안 누적한 변수 출력
				break;
				
			}else if(user.equals("가위") || user.equals("바위") || user.equals("보")) {
				System.out.println("컴퓨터 : " + com);
				System.out.println(name + " : " + user);
				
				String result = ""; // 결과 보관할 변수
				
				if(com.equals(user)) {
					result = "이겼습니다 !";
				}
				
				if(com.equals("가위")) { // com이 가위를 낸 경우
					switch(user) {
					case "가위" : result = "비겼습니다."; break;
					case "바위" : result = "이겼습니다 !"; break;
					case "보" : result = "졌습니다 ㅠㅠ"; break;
					}
				}else if(com.equals("바위")) { // com이 바위를 낸 경우
					switch(user) {
					case "가위" : result = "졌습니다 ㅠㅠ"; break;
					case "바위" : result = "비겼습니다."; break;
					case "보" : result = "이겼습니다 !"; break;
					}
				}else { // com이 보를 낸 경우
					switch(user) {
					case "가위" : result = "이겼습니다 !"; break;
					case "바위" : result = "졌습니다 ㅠㅠ"; break;
					case "보" : result = "비겼습니다."; break;
					}
				}
				System.out.println(result); // 결과 알려주기
				System.out.println();
				
				total++; // 전++
				switch(result) {
				case "이겼습니다 !" : win++; break; // 승++
				case "졌습니다 ㅠㅠ" : lose++; break; // 패++
				default : tie++; break; // 무++
				}
			}else {
				System.out.println("잘못 입력하셨습니다.");
			}
			
			
			
		}
	}

}

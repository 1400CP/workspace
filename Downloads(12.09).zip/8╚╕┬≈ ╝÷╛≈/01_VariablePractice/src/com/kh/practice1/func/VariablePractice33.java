package com.kh.practice1.func;

import java.util.Scanner;

public class VariablePractice33 { 
	
	Scanner sc = new Scanner(System.in);
			
	public void method3() {
	
	System.out.print("가로 :  ");
	double width = sc.nextDouble();
	
	System.out.print("세로 :  ");
	double height = sc.nextDouble();
	
	System.out.print("");

	}
}

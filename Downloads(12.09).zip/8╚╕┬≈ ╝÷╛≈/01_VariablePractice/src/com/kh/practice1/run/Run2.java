package com.kh.practice1.run;

import com.kh.practice1.func.VariablePractice11;
import com.kh.practice1.func.VariablePractice44;

public class Run2 {
	
	public static void main(String[] args)  {
		VariablePractice11 v1 = new VariablePractice11();
		v1.method1();
			
		//VariablePractice22 v2 = new VriablePractice22();
		//v2.method2()
		
		//VariablePractice33 v3 = new VriablePractice33();
		//v3.method3()
		
		//VariablePractice44 v4 = new VriablePractice44();
		//v4.method4()
		
	}

}

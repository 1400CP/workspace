package com.kh.practice.run;

import com.kh.practice.func.OperatorPractice;
import com.kh.practice.func.OperatorPractice2;

public class Run {
	
	public static void main (String[] args){
		
		// OperatorPractice a = new OperatorPractice();
		OperatorPractice2 op = new OperatorPractice2();
		
		// a.practice1();
		// a.practice2();
		// a.practice3();
		// a.practice4();
		// a.practice5();
		// a.practice6();
		// a.practice7();
		// a.practice8();
		// a.practice9();
		// a.practice10();
		// a.practice11();
		
		// op.practice6();
		// op.practice7();
		// op.practice8();
		op.practice11();
		
		
		
	}

}

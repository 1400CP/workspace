package com.kh.chap01.run;

import com.kh.chap01.condition.A_If;
import com.kh.chap01.condition.B_Switch;

public class ConditionRun {
	
	public static void main(String[] args) {
		// A_If a = new A_If();
		B_Switch b = new B_Switch();
		
		
		// a.method1();
		// a.method2();
		// a.method3();
		// a.method4();
		// a.method5(); 
		// a.method6(); 
		// a.method7(); 
		
		// b.method1();
		// b.method2();
		// b.method3();
		b.method4();
		
		
	}
	
	

}

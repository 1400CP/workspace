package com.kh.chap02.run;

import com.kh.chap02.loop.A_For;
import com.kh.chap02.loop.B_While;
import com.kh.chap02.loop.C_DoWhile;

public class LoopRun {
	
	public static void main(String[] args) {
		// A_For a = new A_For();
		// B_While b = new B_While();
		C_DoWhile c = new C_DoWhile();
		
		// c.method1();
		// c.method2();
		c.method3();
		
		// a.method1();
		// a.method2();
		// a.method3();
		// a.method4();
		// a.method5();
		// a.method6();
		// a.method7();
		// a.method8();
		// a.method9();
		// a.method10();
		// a.method11();
		// a.method12();
		// a.method13();
		// a.method14();
		// a.method15();
		// a.method16();
		// a.method17();
		
		// b.method1();
		// b.method2();
		// b.method3();
		// b.method4();
		// b.method5();
		
		
	}
	

}

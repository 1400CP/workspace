package com.kh.chap03.run;

import com.kh.chap03.branch.A_Break;
import com.kh.chap03.branch.B_Continue;

public class BranchRun {

	public static void main(String[] args) {
		
		// A_Break a = new A_Break();
		B_Continue b = new B_Continue();
		
		
		// b.method1();
		// b.method2();
		b.method3();
		
		// a.method1();
		// a.method2();
		// a.method3();
		
		
	}
}

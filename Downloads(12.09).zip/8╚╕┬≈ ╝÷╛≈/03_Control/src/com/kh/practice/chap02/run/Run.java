package com.kh.practice.chap02.run;

import com.kh.practice.chap02.loop.LoopPractice;

public class Run {
	
	public static void main(String[] args) {
		
		LoopPractice a = new LoopPractice();
		
		// a.practice1();
		// a.practice3();
		// a.practice5();
		// a.practice6();
		// a.practice8();
		// a.practice9();
		a.practice11();
		// a.practice13();
		// a.practice14();
		
	}

}

package com.kh.practice.comp.func;

import java.util.Scanner;

public class CompExample {

	public void practice1() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 : ");
		int num = sc.nextInt();
		
		if(num > 0) {
			for(int i=1; i<=num; i++) {
				if(i % 2 == 1) {
					System.out.print('박');
				}else if(i % 2 == 0) {
					System.out.print('수');
				}else
					System.out.println();
			}
			
		}else
			System.out.println("양수가 아닙니다.");
		/*
		for(int i=1; i<=num; i++) {
			if(num % 2 == 1) {
				System.out.println('박');
				if(num % 2 == 0) {
					System.out.println('수');
				}
			}
			
		}
		*/		
		/*
		if(num % 2 == 1 && num > 0) {
			for(int i=1; i<=num; i += 2) {
				System.out.print("박");
			}
		}else if(num % 2 == 0 && num > 0) {
			for(int i=1; i<=num; i++) {
				System.out.print("수");
			}
		}else
			System.out.println("양수가 아닙니다.");
		*/
		
		/*
		for(int i=1; i<=num; i++) {
			if(num % 2 == 1 && num > 0) {
				System.out.print("박");
			}
			for(int j=1; j<=num; j++) {
				if(num % 2 == 0 && num > 0) {
					System.out.print("수");
				}
			}
			if(num < 0) {
				System.out.println("양수가 아닙니다.");
			}
		}
		*/
	}
	
	public void practice2() {

		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.print("정수 : ");
			int num = sc.nextInt();

			if (num > 0) {

				for (int i = 1; i <= num; i++) {
					if (i % 2 == 1) {
						System.out.print('박');
					} else if (i % 2 == 0) {
						System.out.print('수');
					}
				}
				break;

			} else {
				System.out.println("양수가 아닙니다.");
			}
		}

	}
		
	
	
	public void practice3() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("문자열 : ");
		String str = sc.nextLine();
		
		System.out.print("문자 : ");
		char ch = sc.nextLine().charAt(0);
		
		char[] arr = new char[str.length()];
		
		for(int i=0; i<str.length(); i++) {
			arr[i] = str.charAt(i);
		}
		int count = 0;
		for(int i=0; i<str.length(); i++) {
			if(arr[i] == ch) {
				count++;
			}	
		}
		System.out.println(str + "안에 포함된 " + ch + "개수 : " + count);
		
		/*
		String result = str + "안에 포함된 " + ch + " 개수 : ";
		System.out.print(result);
		
		for(int i = 0; i<str.length(); i++) {
			
		}
		*/
		
		
	}
	
	public void practice4() {
		
		Scanner sc = new Scanner(System.in);
		
		int count = 0;
		
		while(true) {
			System.out.println("문자열 : ");
			String str = sc.nextLine();
			
			System.out.println("문자 : ");
			char ch = sc.nextLine().charAt(0);
			
			for(int i=0; i<str.length(); i++) {
				if(str.charAt(i) == ch) {
					count++;
				}
				
			}
			
			System.out.println("포함된 개수 : " + count);
			System.out.println("더할래? : ");
			char yn = sc.nextLine().charAt(0);
			
			if(yn == 'n' || yn == 'N') {
				System.out.println("종료한다.");
				break;
			}else if (yn =='y' || yn == 'Y'){
				
			}else {
				System.out.println("잘못했다. 다시 입력해.");
			}
			
		}
	
	}
			
	/*
		while(true) {
			System.out.print("문자열 : ");
			String str = sc.nextLine();
			
			System.out.print("문자 : ");
			char ch = sc.nextLine().charAt(0);
			
			char[] arr = new char[str.length()];
			
			for(int i=0; i<str.length(); i++) {
				arr[i] = str.charAt(i);
			}
			int count = 0;
			for(int i=0; i<str.length(); i++) {
				if(arr[i] == ch) {
					count++;
				}	
			}
			System.out.println(str + "안에 포함된 " + ch + "개수 : " + count);
			while(true) {
				System.out.print("더 하시겠습니까? (y/n) : ");
				String q = sc.nextLine();
	
				if(q.equals("y") && q.equals("Y")) { 
					
				}else if(q.equals("n") && q.equals("N")) {
					break;
				}else
					System.out.println("잘못된 대답입니다. 다시 입력해주세요.");
			} break;
				
		}	
		
		// (System.out.println("더 하시겠습니까? ")
	}
	*/
	public void practice5() {
		
		// UpAndDown.java = new UpAndDown();
		
		
	}
	
	public void practice6() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("당신의 이름을 입력해주세요 : ");
		String name = sc.nextLine();
		
		
		
		while(true) {
			
		System.out.print("가위바위보 : ");
		String game = sc.nextLine();
		
		if(game.equals("exit")) {
			break;
		}else if (game.equals("가위") || game.equals("바위") || game.equals("보")) {
			System.out.println(game);
		}else
			System.out.println("잘못 입력하셨습니다.");
			System.out.println();
		
		int num = (int)(Math.random() * 3 + 1);
		
		if(num == 1) {
			System.out.println("가위");
		}else if(num == 2) {
			System.out.println("바위");
		}else if(num == 3) {
			System.out.println("보");
		}
		
		int total = 0;
		int win = 0;
		int lose = 0;
		int tie = 0;
		
			if(game.equals("가위")) {
				if(num == 1) {
					System.out.println("비겼습니다.");
					System.out.println();
					tie++;
				}else if(num == 2) {
					System.out.println("이겼습니다.");
					System.out.println();
					win++;
				}else if(num == 3) {
					System.out.println("졌습니다.");
					System.out.println();
					lose++;
				}
			}
			if(game.equals("바위")) {
				if(num == 1) {
					System.out.println("이겼습니다");
					System.out.println();
					win++;
				}else if(num == 2) {
					System.out.println("비겼습니다");
					System.out.println();
					tie++;
				}else if(num == 3) {
					System.out.println("졌습니다.");
					System.out.println();
					lose++;
				}
			}
			if(game.equals("보")) {
				if(num == 1) {
					System.out.println("졌습니다.");
					System.out.println();
					lose++;
					
				}else if(num == 2) {
					System.out.println("이겼습니다.");
					System.out.println();
					win++;
				}else if(num == 3) {
					System.out.println("비겼습니다.");
					System.out.println();
					tie++;
				}
				
			}
			total++;
			System.out.println(total + "전 " + win + "승 " + tie + "무 " + lose + "패");
		}
		
	}
	
}
		
/*
		while(true) {
			int random = (int)(Math.random() * 3 + 1); // 1, 2, 3
			String com = "";
			
			switch(random) {
			case 1 : com = "가위"; break;
			case 2 : com = "바위"; break;
			case 3 : com = "보"; break;
			}
			
			System.out.println("가위바위보 : ");
			String user = sc.nextLine();
			
			if(user.equals("exit")) {
				// 전승무패 출력
				System.out.println("%d"전 "%d"승 "%d"무 "%d"패, total, win, tie, lose);
				// 끝냄
			}else if(user.equals("가위") || user.equals("바위") || user.equals("보")) {
				System.out.println("컴퓨터 : " + com);
				System.out.println(name + " : " + user);
				
				String result = "";
				if(com.equals(user)) {
					result = "비겼습니다.";
				}
				
				if(com.equals("가위")) {				// 컴이 가위를 낸 경우
					switch(user) {
					case "바위" : result = "이겼습니다."; break;
					case "보" : result = "졌습니다."; break;
					}
				}else if(com.equals("바위")) {
					switch(user) {
					case "가위" : result = "졌습니다."; break;
					case "보" : result = "이겼습니다."; break;
					}
				}else {								// 컴이 보를 낸 경우
					switch(user) {
					case "가위" : result = "이겼습니다."; break;
					case "바위" : result = "졌습니다."; break;
					}
				}
				System.out.println(result);
				System.out.println();
				
				total++;
				switch(result) {
				case "이겼습니다." : win++; break;
				case "졌습니다." : lose++; break;
				default : tie++; break;
				}
			}else {
				System.out.println("잘못 입력하셨습니다.");
			}
*/	
package com.kh.practice.comp.run;

import com.kh.practice.comp.func.CompExample;
import com.kh.practice.comp.func.UpAndDown;

public class Run {

	public static void main (String[] args) {
		
		CompExample a = new CompExample();
		// UpAndDown b = new UpAndDown(); 
		
		// b.upDown(); //count에서 틀린다. 어떻게 해야 하지? (풀이했음 정리하자)
		
		
		// a.practice1(); 완성
		// a.practice2(); 완성
		// a.practice3(); 완성
		a.practice4();
		// y/n에서 틀린다. 뭐가 문제인지 모르겠다. (풀이했음 정리하자)
		// a.practice6(); count 하는 법을 모르겠다.
		
		
	}
	
}

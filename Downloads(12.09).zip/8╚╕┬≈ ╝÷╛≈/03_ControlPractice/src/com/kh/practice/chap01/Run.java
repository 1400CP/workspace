package com.kh.practice.chap01;

public class Run {

	public static void main(String[] args) {
		
		// ControlPractice a = new ControlPractice();
		
		ControlPractice22 b = new ControlPractice22();
		
		// a.practice1();
		// a.practice2();
		// a.practice3();
		// a.practice4();
		// a.practice5();
		// a.practice6();
		// a.practice7();
		// a.practice8();
		// a.practice9();
		// a.practice10();
		
		// b.practice5();
		// b.practice7();
		// b.practice8();
		// b.practice9();
		b.practice10();
		
	}
	
}

package com.kh.practice.array;

import java.util.Scanner;

public class ArrayPractice {
	
	public void practice1() {
		
		int[] arr = new int[10];
		
		for(int i=0; i<arr.length; i++) {
			arr[i] = i+1;						// 결과값이 i+1 이라는 걸 넣어줘야 한다.
			System.out.print(arr[i] + " ");
		}
		
	}

	public void practice2() {					// 아직 못 품. 역순 어케 하지?
		// 1번에서 역순으로 바꾸기
		
		int[] arr = new int[10];
		
		arr[0] = 10;
		arr[1] = 9;
		arr[2] = 8;
		
		for(int i=0; i<arr.length ; i++) {
			arr[i] = i+1;
			System.out.print(arr[i] + " ");
		}
		
		
	}
	
	public void practice3() {
		//사용자에게 입력받은양의 정수만큼 배열크기를 할당하고
		Scanner sc = new Scanner(System.in);
		
		System.out.print("양의 정수 : ");
		int num = sc.nextInt();
		int[] arr = new int[num];
				
		//1부터 입력받은 값까지 배열에 초기화한 후출력하세요
		/*
		 * arr[0] = 1	초기화	arr[0] = 1
		 * arr[1] = 2			arr[1] = 2
		 * arr[2] = 3			...
		 */
		
		for(int i=0; i<arr.length; i++) {
			arr[i] = i+1;
			System.out.print(arr[i] + " ");
			
		}
		
	}
	
	public void practice4() {
		/*
		 * 길이가 5인 String배열을 선언하고 “사과”, “귤“, “포도“, “복숭아”, “참외“로
		 * 초기화한 후 배열 인덱스를 활용해서 귤을 출력하세요.
		 * 초기화 한다는 말이 무슨 뜻이지?					=> 직접 입력하란 뜻이었다.
		 */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("배열용 길이 5인 선언 : ");
		
		
		String str = sc.nextLine();
		int[] arr = new int[str.length()];
		
		for(int i=0; i<arr.length; i++) {
			
		}
		
		
		
		
		
		/*										이건 단어 분해용, 추출기임.
		char[] arr = new char[str.length()];
		
		for(int i=0; i<arr.length; i++) {
			arr[i] = str.charAt(i);
			System.out.println(arr[i]);
		}
		*/
		
		
	}
	
	public void practice5() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("문자열 : ");
		String word = sc.nextLine();
		// 문자열을 입력 받아
		char[] arr = new char[word.length()];
		
		
		System.out.print("문자 : ");
		char tx = sc.nextLine().charAt(0);

		// 문자 하나하나를 배열에 넣고 검색할 문자가 문자열에 몇개 들어가 있는지
		
		// 개수와 몇번째 인덱스에 위치하는지 인덱스를 출력하세요
		int count = 0;						//개수 세야지.	
		//쪼개기는 완성
			for(int i=0; i<arr.length; i++) {
				arr[i] = word.charAt(i);
					if(tx == arr[i]) {
					count++;
					
					}
				System.out.println("arr[" + i + "] : " + arr[i]);
				
			}
			
			System.out.println("i 개수 : " + count);
	}	

	@SuppressWarnings("unlikely-arg-type")
	public void practice6() {
		/* “월“ ~ “일”까지 초기화된 문자열 배열을 만들고
		 * 
		 *  0부터 6까지 숫자를 입력 받아
		 *  입력한 숫자와 같은 인덱스에 있는 요일을 출력하고
		 *  범위에 없는 숫자를 입력 시 “잘못 입력하셨습니다“ 를 출력하세요
		 */
		
		Scanner sc = new Scanner(System.in);
		
		String[] day = {"월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"};
		// 초기화된 문자열 배열
		// System.out.println(day[1]);
		
		System.out.print("0 ~ 6 사이 숫자 입력 : ");
		int num = sc.nextInt();
		int[] arr = new int[num];
		//숫자를 입력 받아
		
		for(int i=0; i<num; i++) {
			day[i].equals(arr[i]);
			System.out.println(day[i]);
		}
		
		/*
		for(int i=0; i<7; i++) {
			if(day[i] == )
		}
		*/
		
		/*
		 * arr[0] = 월 요일
		 * arr[1] = 화 요일
		 * arr[2] = 수 요일
		 * arr[3] = 목 요일
		 * arr[4] = 금 요일
		 */
		
		/*
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("0 ~ 6 사이 숫자 입력 : ");
		int num = sc.nextInt();
		System.out.println();
		*/
		
	}
	
	public void practice7() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 : ");
		int num = sc.nextInt();
		//사용자가 배열의 길이를 직접 입력
		
		int[] arr = new int[num];
		//사용자가 배열의 길이를 직접 입력
		
		
		for(int i=0; i<num; i++) {
			int value = sc.nextInt();
			arr[i] = value;
			System.out.print("배열 " + i + "번째 인덱스에 넣을 값 : " );
		// 배열의 크기만큼 직접 값을 반복해서 입력(초기화)
		}
		
		int sum = 0;
		
		for(int i=0; i<num; i++) {
			sum += arr[i];
		}
		System.out.println("총 합 : " + sum);
			
		
		
	}
	
	public void practice8() {
		/*
		3이상인 홀수 자연수를 입력받아 배열의 중간까지는 1부터 1씩 증가하여 오름차순으로 값을 넣고,
		중간 이후부터 끝까지는 1씩 감소하여 내림차순으로 값을 넣어 출력하세요.
		단, 입력한 정수가 홀수가 아니거나 3미만일 경우 “다시 입력하세요” 를 출력하고
		다시 정수를 받도록 하세요
		 */
		
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
				
		
		
		
		
	}
	
	public void practice9() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("치킨 이름을 입력하세요 : ");
		String name = sc.nextLine();
		
		for(int i=0; i<name.length(); i++) {
			
		}
			
	}
	
	
	
}			

package com.kh.practice.run;

import java.util.concurrent.ArrayBlockingQueue;

import com.kh.practice.array.ArrayPractice;

public class Run {
	
	public static void main (String[] args) {
		
		ArrayPractice a = new ArrayPractice();
		
		// a.practice1();
		// a.practice2();		못품
		// a.practice3();
		// a.practice4();		못품
		a.practice5();		
		// a.practice6();		// 날짜가 지정되게 수정하자.
		// a.practice7();		// 일부를 모르겠다. 합계쪽	
		// a.practice8();		// 감이 안 잡힘. 아예 모르겠음.		
		// a.practice9();		// 시작해야 함.
		
		
		
	}
		
			
	

}

package com.kh.run;

import com.kh.array.A_Array;
import com.kh.array.B_Array;

public class ArrayRun {
	
	public static void main(String[] args) {
		
		// A_Array a = new A_Array();
		// B_Array b = new B_Array();
		
		// b.method1();
		// b.method2();
		// b.method3();
		// b.method4();
		// b.method5();
		
		// a.method1();
		// a.method2();
		// a.method3();
		// a.method4();
		// a.method5();
		// a.method6();
		// a.method7();
		// a.method8();
		// a.method9();
		// a.method10();
		// a.method11();
		
		
	}

}
